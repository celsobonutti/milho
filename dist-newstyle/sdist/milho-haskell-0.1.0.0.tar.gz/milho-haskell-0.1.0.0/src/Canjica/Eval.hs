module Canjica.Eval where

import qualified Canjica.Internal as Internal
import Protolude

eval = Internal.eval
eval' = Internal.eval'
eval'' = Internal.eval''
